// 移动端菜单切换
const menuToggle = document.createElement('button');
menuToggle.className = 'menu-toggle';
menuToggle.innerHTML = '<i class="fas fa-bars"></i>';
document.querySelector('.navbar').appendChild(menuToggle);

menuToggle.addEventListener('click', () => {
    document.querySelector('.nav-menu').classList.toggle('active');
});

// 语言切换功能
document.querySelectorAll('.lang-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        // 切换按钮状态
        document.querySelectorAll('.lang-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        
        // 切换内容显示
        const lang = btn.dataset.lang;
        document.querySelectorAll('[data-lang]').forEach(el => {
            el.style.display = el.dataset.lang === lang ? 'block' : 'none';
        });
    });
});

// 响应式图片加载
function loadResponsiveImages() {
    const images = document.querySelectorAll('img[data-src]');
    images.forEach(img => {
        const src = window.innerWidth >= 768 ? img.dataset.srcDesktop : img.dataset.srcMobile;
        img.src = src;
    });
}

window.addEventListener('resize', loadResponsiveImages);
window.addEventListener('load', loadResponsiveImages);

// 移动端菜单切换
const menuToggle = document.querySelector('.menu-toggle');
const navMenu = document.querySelector('.nav-menu');

menuToggle.addEventListener('click', () => {
  navMenu.classList.toggle('active');
  menuToggle.classList.toggle('active');
});

// 关闭移动菜单当点击外部区域
document.addEventListener('click', (e) => {
  if (!navMenu.contains(e.target) && !menuToggle.contains(e.target)) {
    navMenu.classList.remove('active');
    menuToggle.classList.remove('active');
  }
});

// 语言切换功能
function updateLanguage(lang) {
  // 文本切换
  document.querySelectorAll('[data-lang]').forEach(el => {
    el.style.display = el.dataset.lang === lang ? 'block' : 'none';
  });

  // 按钮状态
  document.querySelectorAll('.lang-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.lang === lang);
  });

  // 保存到本地存储
  localStorage.setItem('preferredLang', lang);
}

// 初始化语言设置
const preferredLang = localStorage.getItem('preferredLang') || 'zh';
updateLanguage(preferredLang);

// 语言切换事件
document.querySelectorAll('.lang-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    updateLanguage(btn.dataset.lang);
  });
});

// 滚动动画
const observerOptions = {
  threshold: 0.1
};

const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('visible');
    }
  });
}, observerOptions);

document.querySelectorAll('.service-card, .portfolio-item').forEach(el => {
  el.classList.add('fade-in');
  observer.observe(el);
});

// 表单验证（示例）
document.querySelectorAll('form').forEach(form => {
  form.addEventListener('submit', (e) => {
    const inputs = form.querySelectorAll('input, textarea');
    let isValid = true;

    inputs.forEach(input => {
      if (!input.checkValidity()) {
        isValid = false;
        input.classList.add('invalid');
      }
    });

    if (!isValid) {
      e.preventDefault();
      inputs.forEach(input => {
        input.addEventListener('input', () => {
          if (input.checkValidity()) {
            input.classList.remove('invalid');
          }
        });
      });
    }
  });
});

// 图片懒加载
const lazyImages = document.querySelectorAll('img[loading="lazy"]');

const imgObserver = new IntersectionObserver((entries, observer) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      const img = entry.target;
      img.src = img.dataset.src;
      img.removeAttribute('data-src');
      observer.unobserve(img);
    }
  });
});

lazyImages.forEach(img => {
  img.dataset.src = img.src;
  img.removeAttribute('src');
  imgObserver.observe(img);
});

function updateOfficeStatus() {
    const hours = new Date().getHours();
    const isOpen = hours >= 9 && hours < 18;
    document.querySelectorAll('.office-status').forEach(el => {
      el.textContent = isOpen ? '营业中' : '已下班';
    });
  }